package example;

import java.util.Date;

/**
 * example.User
 * @author Jason Carreira
 * Date: Mar 29, 2004 9:54:53 PM
 */
public class User {
    private String name;
    private Date birthday;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getBirthday() {
        return birthday;
    }

    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }
}
