package example.ex3;

import com.opensymphony.xwork.ActionSupport;
import com.opensymphony.xwork.ModelDriven;

import java.util.Date;

import example.User;

/**
 * example.ex1.HelloWorldAction
 * @author Jason Carreira
 * Date: Mar 29, 2004 9:59:17 PM
 */
public class HelloWorldAction extends ActionSupport {
    private User user = new User();

    public int getDaysTillNextBirthday() {
        Date birthday = user.getBirthday();
        if (birthday != null) {
            return calculateDaysTillNextBirthday(birthday);
        }
        return 0;
    }

    public String execute() throws Exception {
        return SUCCESS;
    }

    private int calculateDaysTillNextBirthday(Date birthday) {
        return 1;
    }

    public Object getUser() {
        return user;
    }
}
