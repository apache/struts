package example.ex1;

import junit.framework.TestCase;
import com.opensymphony.xwork.Action;

import java.util.Map;
import java.util.List;

/**
 * HelloWorldActionTest
 * @author Jason Carreira
 * Date: Apr 2, 2004 12:27:17 AM
 */
public class HelloWorldActionTest extends TestCase {
    public void testFieldErrorAddedWhenNoUserName() throws Exception {
        HelloWorldAction action = new HelloWorldAction();
        assertEquals(Action.INPUT, action.execute());
        assertTrue(action.hasFieldErrors());
        Map fieldErrors = action.getFieldErrors();
        assertTrue(fieldErrors.containsKey("user.name"));
        List userNameErrors = (List) fieldErrors.get("user.name");
        assertEquals(1, userNameErrors.size());
        assertEquals("You must enter a name.",userNameErrors.get(0));
    }
}
