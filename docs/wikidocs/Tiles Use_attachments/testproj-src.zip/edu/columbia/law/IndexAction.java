/******************************************************************************
 *
 *                 Columbia University, School Of Law (CLS)
 *
 *                            PROPRIETARY DATA
 *
 *      THIS DOCUMENT CONTAINS TRADE SECRET DATA WHICH IS THE PROPERTY OF
 *      CLS.  THIS DOCUMENT IS SUBMITTED TO RECIPIENT IN CONFIDENCE.
 *      INFORMATION CONTAINED HEREIN MAY NOT BE USED, COPIED OR
 *      DISCLOSED IN WHOLE OR IN PART EXCEPT AS PERMITTED BY WRITTEN AGREEMENT
 *      SIGNED BY AN OFFICER OF IT AT CLS
 *
 *      THIS MATERIAL IS ALSO COPYRIGHTED AS AN UNPUBLISHED WORK UNDER
 *      SECTIONS 104 AND 408 OF TITLE 17 OF THE UNITED STATES CODE.
 *      UNAUTHORIZED USE, COPYING OR OTHER REPRODUCTION IS PROHIBITED BY LAW.
 *
 ******************************************************************************/
package edu.columbia.law;

import com.opensymphony.xwork.ActionSupport;

/**
 * 
 *
 * @author <a href="mailto:alex@law.columbia.edu">Alex Shneyderman</a>
 * @since  Jan 19, 2006
 * @version $Revision$
 * <pre>
 * $Log$ </pre>
 */
public class IndexAction extends ActionSupport {

    private String page;
    public String getPage () { return page; }
    public void setPage (String page) { this.page = page; }
    
    @Override
    public String execute () throws Exception {
        if (getPage() != null) {
            return page;
        } else {
            return SUCCESS;
        }
    }
    
}
