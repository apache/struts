java
------
Project source code resides in this directory.  Files here are compiled into classes placed in ${project.dir}/target/classes and added to the compile classpath.

You may remove this file once you understand the project structure and the purpose of this directory: this file also serves as a "empty directory" placeholder so CVS won't prune the directory.
